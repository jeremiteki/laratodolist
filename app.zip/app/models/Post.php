<?php

class Post extends Eloquent {
	protected $fillable = array('name','body');
}